<?php

	if(!defined('WP_UNINSTALL_PLUGIN'))
		die;
	if(get_option('t-film-plugin'))
		delete_option('t-film-plugin');

?>