<div class="col-12 text-center">
	<img src="<?= get_template_directory_uri().'/img/film-not-found.png'?>" class="w-25">
	<h6 class="my-2"><?= __('Không tìm thấy phim phù hợp', 't-film') ?></h6>
</div>