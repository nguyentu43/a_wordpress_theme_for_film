# Simple Film Theme Wordpress

[Demo](http://delayed-act.000webhostapp.com/)

![Demo Img](https://github.com/nguyentu43/simplefilmtheme/raw/master/screenshot.png) 